//
//  ContentView.swift
//  Unit 9 First Look
//
//  Created by Sol Kim on 4/12/22.
//

import SwiftUI

struct ContentView: View {
    @State var data: BBCharacter?
    
    var body: some View {
        Text(data?.author ?? "default value")
            .onAppear {
                let urlString = "https://breaking-bad-quotes.herokuapp.com/v1/quotes"
                getData(from: urlString) { data in
                    self.data = data
                }
            }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
