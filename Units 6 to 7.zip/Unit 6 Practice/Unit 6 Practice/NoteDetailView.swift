//
//  NoteDetailView.swift
//  Unit 6 Practice
//
//  Created by Sol Kim on 1/12/22.
//

import SwiftUI

struct NoteDetailView: View {
    var note: Note
    
    var body: some View {
        Text(note.title)
            .font(.title)
        Text("By: \(note.name)")
            .foregroundColor(.gray)
        Text(note.text)
    }
}
