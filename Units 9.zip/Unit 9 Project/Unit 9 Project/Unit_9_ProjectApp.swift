//
//  Unit_9_ProjectApp.swift
//  Unit 9 Project
//
//  Created by Sol Kim on 4/21/22.
//

import SwiftUI

@main
struct Unit_9_ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
