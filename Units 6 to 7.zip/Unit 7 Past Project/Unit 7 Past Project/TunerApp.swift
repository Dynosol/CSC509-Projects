//
//  TunerApp.swift
//  Unit 7 Project
//
//  Created by Sol Kim on 2/10/22.
//

import SwiftUI

struct TunerApp: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct TunerApp_Previews: PreviewProvider {
    static var previews: some View {
        TunerApp()
    }
}
