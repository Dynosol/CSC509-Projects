//
//  NapScreen.swift
//  Unit 6 Project
//
//  Created by Sol Kim on 1/18/22.
//

import SwiftUI

struct NapScreen: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct NapScreen_Previews: PreviewProvider {
    static var previews: some View {
        NapScreen()
    }
}
