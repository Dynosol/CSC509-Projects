//
//  ContentView.swift
//  Unit 9 First Look
//
//  Created by Sol Kim on 4/12/22.
//

import SwiftUI

let sWidth = UIScreen.main.bounds.width
let sHeight = UIScreen.main.bounds.height

// Global custom color variables
// Once again, learned color extension from:
// https://stackoverflow.com/questions/58516229/how-to-add-a-new-swiftui-color
extension Color {
    static let tan = Color(red: 255/255, green: 224/255, blue: 179/255)
    static let lightGray = Color(red: 230/255, green: 230/255, blue: 230/255)
}

struct ContentView: View {
    @State var data: URLResult?
    
    var body: some View {
        VStack {
            CardView(data: $data)
        }
        .frame(width: sWidth, height: sHeight)
        .background(Color.gray)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
