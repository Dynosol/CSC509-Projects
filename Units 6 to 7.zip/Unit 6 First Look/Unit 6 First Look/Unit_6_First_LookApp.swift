//
//  Unit_6_First_LookApp.swift
//  Unit 6 First Look
//
//  Created by Sol Kim on 1/10/22.
//

import SwiftUI

@main
struct Unit_6_First_LookApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
