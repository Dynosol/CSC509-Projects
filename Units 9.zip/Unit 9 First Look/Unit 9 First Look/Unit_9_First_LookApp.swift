//
//  Unit_9_First_LookApp.swift
//  Unit 9 First Look
//
//  Created by Sol Kim on 4/12/22.
//

import SwiftUI

@main
struct Unit_9_First_LookApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
