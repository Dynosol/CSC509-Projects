//
//  Unit_9_PracticeApp.swift
//  Unit 9 Practice
//
//  Created by Sol Kim on 4/19/22.
//

import SwiftUI

@main
struct Unit_9_PracticeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
