//
//  NewNoteView.swift
//  Unit 6 Practice
//
//  Created by Sol Kim on 1/11/22.
//

import SwiftUI

struct NewNoteView: View {
    @Environment(\.presentationMode) var presentationMode
    
    @ObservedObject var noteModel: NoteModel
    @State var newTitle = ""
    @State var newName = ""
    @State var newText = ""
    
    func legal(title: String, name: String, text: String) -> Bool {
        if (title != "" && name != "" && text != "") {
            return true
        }
        return false
    }
    
    var body: some View {
        Form {
            TextField("Note title", text: $newTitle)
            TextField("Your name", text: $newName)
            TextField("Note text", text: $newText)
            
            Button(action: {
                if legal(title: newTitle, name: newName, text: newText) {
                    noteModel.notes.append(Note(title: newTitle, name: newName, text: newText))
                    newTitle = ""
                    newName = ""
                    newText = ""
                    
                    presentationMode.wrappedValue.dismiss()
                }
            }, label: {
                Text("Create Note")
            })
        }
    }
}
