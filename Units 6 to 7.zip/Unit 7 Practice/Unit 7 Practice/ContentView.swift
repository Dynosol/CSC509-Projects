//
//  ContentView.swift
//  Unit 7 Practice
//
//  Created by Sol Kim on 2/7/22.
//

// Sources Cited:
//1) https://stackoverflow.com/questions/64654677/swiftui-change-images-on-a-timer-with-animation

import SwiftUI

struct ContentView: View {
    @StateObject var userModel = UserModel(player: PlayerItem(username: "", clicks: 0))
    
    var body: some View {
        NavigationView{
            VStack {
                NavigationLink(destination: EditUser(userModel: userModel), label: {
                    Text("Settings")
                })
                
                DancingDog(userModel: userModel)
            }
            .toolbar {
                ToolbarItem(placement: .principal) {
                    VStack {
                        Text("Title").font(.headline)
                        Text("Subtitle").font(.subheadline)
                    }
                    .background(colorinator(carray: [230,230,230]))
                }
            }
        }
    }
}

struct DancingDog: View {
    @ObservedObject var userModel: UserModel
    
    @State var activeImageIndex = 0 // Index of the currently displayed image
    
    // Learned from:
    // https://stackoverflow.com/questions/64654677/swiftui-change-images-on-a-timer-with-animation
    let imageSwitchTimer = Timer.publish(every: 0.05, on: .main, in: .common)
            .autoconnect()
    
    var body: some View {
        VStack {
            // Information Bar
            Text("\(userModel.player.clicks)")
            
            // Dancing Dog
            Button(action: {
                userModel.player.clicks += 1
            }, label: {
                Image("maindog-\(activeImageIndex)")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding()
                    .transition(.asymmetric(insertion: .scale, removal: .opacity))
                    .animation(.spring())
                    .onReceive(imageSwitchTimer) { _ in
                        self.activeImageIndex = (self.activeImageIndex + 1) % 63
                    }
            })
            .frame(width: 200, height: 200)
            .border(Color.black, width: 1)
        }
    }
}

struct EditUser: View {
    @ObservedObject var userModel: UserModel
    
    var body: some View {
        Form {
            TextField("Set Username", text: $userModel.player.username)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

class UserModel: ObservableObject {
    @Published var player: PlayerItem {
        didSet {
            if let encoded = try? JSONEncoder().encode(player) {
                UserDefaults.standard.set(encoded, forKey: "playerinfo")
            }
        }
    }
    
    init(player: PlayerItem) {
        if let data = UserDefaults.standard.object(forKey: "playerinfo") {
            if let loadedPlayer = try? JSONDecoder().decode(PlayerItem.self, from: data as! Data) {
                self.player = loadedPlayer
                return
           }
        }
        self.player = player
    }
}

struct PlayerItem: Identifiable, Codable {
    var id = UUID()
    var username: String
    var clicks: Int
}

// Function that turns the playermodel color values (array of ints) into a color
func colorinator(carray: [Int]) -> Color {
    return Color(red: Double(CGFloat(carray[0])/255), green: Double(CGFloat(carray[1])/255), blue: Double(CGFloat(carray[2])/255))
}
