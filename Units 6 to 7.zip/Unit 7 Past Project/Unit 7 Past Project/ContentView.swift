//
//  ContentView.swift
//  Unit 7 Project
//
//  Created by Sol Kim on 2/8/22.
//

// Sources Cited:
//1) https://shinerightstudio.com/posts/ios-tuner-app-using-audiokit/
//2) https://medium.com/geekculture/simple-modular-classes-for-some-common-audiokit-v5-controls-fa5f264d376f

import SwiftUI

struct ContentView: View {
    @StateObject var userModel = UserModel(user: UserItem(currentPitch: "A"))
    
    var body: some View {
        TunerApp()
    }
}

class UserModel: ObservableObject {
    @Published var user: UserItem {
        didSet {
            if let encoded = try? JSONEncoder().encode(user) {
                UserDefaults.standard.set(encoded, forKey: "userinfo")
            }
        }
    }
    
    init(user: UserItem) {
        if let data = UserDefaults.standard.object(forKey: "userinfo") {
            if let loadedUser = try? JSONDecoder().decode(UserItem.self, from: data as! Data) {
                self.user = loadedUser
                return
           }
        }
        self.user = user
    }
}

struct UserItem: Identifiable, Codable {
    var id = UUID()
    var currentPitch: String
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

