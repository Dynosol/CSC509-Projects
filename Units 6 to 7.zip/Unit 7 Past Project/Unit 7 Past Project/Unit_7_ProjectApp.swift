//
//  Unit_7_ProjectApp.swift
//  Unit 7 Project
//
//  Created by Sol Kim on 2/8/22.
//

import SwiftUI

@main
struct Unit_7_ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
