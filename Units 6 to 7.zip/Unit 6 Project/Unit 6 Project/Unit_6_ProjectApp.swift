//
//  Unit_6_ProjectApp.swift
//  Unit 6 Project
//
//  Created by Sol Kim on 1/18/22.
//

import SwiftUI

@main
struct Unit_6_ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
