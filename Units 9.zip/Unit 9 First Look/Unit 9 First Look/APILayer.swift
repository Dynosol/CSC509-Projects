//
//  APILayer.swift
//  Unit 9 First Look
//
//  Created by Sol Kim on 4/12/22.
//

import Foundation

struct BBCharacter: Codable {
    let quote: String
    let author: String
}

func getData(from urlString: String, completion: @escaping (BBCharacter) -> Void) {
    guard let url = URL(string: urlString) else {
        // if here, url was bad
        return
    }

    URLSession.shared.dataTask(with: url) { data, response, error in
        if let data = data {
            // data non-optional, i.e. it actually exists
            let dataAsString = String(data: data, encoding: .utf8)
            if let dataAsString = dataAsString {
                print(dataAsString)
            }
            
            let decoder = JSONDecoder()
            
            if let characterData = try? decoder.decode([BBCharacter].self, from: data) {
                // successfully made the Swift objects
                completion(characterData[0])
            }
        }
    }.resume()
}


