//
//  ContentView.swift
//  Unit 6 Practice
//
//  Created by Sol Kim on 1/11/22.
//

import SwiftUI

let sWidth = UIScreen.main.bounds.width

struct ContentView: View {
    @StateObject var noteModel = NoteModel(notes:
    [
        Note(title: "First Note!", name: "Bob Dylan", text: "Hey this is me, the real Bob Dylan making a note."),
        Note(title: "Grocery List", name: "mom", text: "bananas, salt, bell peppers, lettuce, rice, flour, asparagus")
    ])
    
    var body: some View {
        NavigationView {
            VStack {
                NavigationLink(destination: NewNoteView(noteModel: noteModel),
                    label: {
                        Image(systemName: "plus.square")
                            .resizable()
                            .frame(width: sWidth*(0.08), height: sWidth*(0.08))
                    }
                ).padding()
                
                ForEach(0..<noteModel.notes.count, id: \.self) {i in
                    NoteView(note: noteModel.notes[i])
                }
            }
        }
    }
}

class NoteModel: ObservableObject {
    @Published var notes: [Note] {
        didSet {
            let encoder = JSONEncoder()
            UserDefaults.standard.set(try? encoder.encode(notes), forKey: "notes")
        }
    }
    
    init(notes: [Note]) {
        let decoder = JSONDecoder()
        
        if let data = UserDefaults.standard.object(forKey: "notes") as? Data,
           let loadedNotes = try? decoder.decode([Note].self, from: data)
        {
            self.notes = loadedNotes
        } else {
            self.notes = notes
        }
    }
}

struct Note: Codable {
    var title: String
    var name: String
    var text: String
}

struct NoteView: View {
    @State private var clicked = false
    
    var note: Note
    
    var body: some View {
        VStack {
            NavigationLink(destination: NoteDetailView(note: note), label: {
                ZStack {
                    Rectangle()
                        .foregroundColor(.yellow)
                        .frame(width: sWidth*(0.9), height: sWidth*(0.1))
                        .cornerRadius(sWidth*(0.02))
                
                    Text(note.title)
                }
            })
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
