//
//  ContentView.swift
//  Unit 6 First Look
//
//  Created by Sol Kim on 1/10/22.
//

import SwiftUI

let sWidth = UIScreen.main.bounds.width

struct ContentView: View {
    @StateObject var intModel = IntModel(ints: [1,2,3,4,5,6,7,8,9])
    
    var body: some View {
        NavigationView {
            VStack {
                NavigationLink(destination: ButtonView(intModel: intModel),
                    label: {
                        Image(systemName: "plus.square")
                            .resizable()
                            .frame(width: sWidth*(0.08), height: sWidth*(0.08))
                    }
                ).padding()
                
                ForEach(0..<intModel.ints.count, id: \.self) {i in
                    Text(String(intModel.ints[i]))
                }
            }
        }
    }
}

struct ButtonView: View {
    @Environment(\.presentationMode) var presentationMode
    
    @ObservedObject var intModel: IntModel
    
    var body: some View {
        VStack {
            Button(action: {
                intModel.ints.append(3)
            }, label: {
                Text("Add 3")
            })
            
            Button(action: {
                intModel.ints.append(5)
                presentationMode.wrappedValue.dismiss()
            }, label: {
                Text("Add 5")
            })
        }
    }
}

class IntModel: ObservableObject {
    @Published var ints: [Int]
    
    init(ints: [Int]) {
        self.ints = ints
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
