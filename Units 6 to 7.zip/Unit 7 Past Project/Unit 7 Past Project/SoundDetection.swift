//
//  SoundDetection.swift
//  Unit 7 Project
//
//  Created by Sol Kim on 2/10/22.
//

// For audio input
import AudioKit
import Foundation

// Note class from https://shinerightstudio.com/posts/ios-tuner-app-using-audiokit/
class Note: Equatable {
    enum Accidental: Int { case natural = 0, sharp, flat }
    enum Name: Int { case a = 0, b, c, d, e, f, g }
    
    // All the 12 notes in an octave.
    static let all: [Note] = [
        Note(.c, .natural), Note(.c, .sharp),
        Note(.d, .natural),
        Note(.e, .flat), Note(.e, .natural),
        Note(.f, .natural), Note(.f, .sharp),
        Note(.g, .natural),
        Note(.a, .flat), Note(.a, .natural),
        Note(.b, .flat), Note(.b, .natural)
    ]
    
    var note: Name
    var accidental: Accidental
    
    // Initializer.
    init(_ note: Name, _ accidental: Accidental) {
        self.note = note
        self.accidental = accidental
    }

    // Equality operators.
    static func ==(lhs: Note, rhs: Note) -> Bool {
        return lhs.note == rhs.note && lhs.accidental == rhs.accidental
    }
    
    static func !=(lhs: Note, rhs: Note) -> Bool {
        return !(lhs == rhs)
    }
    
    var frequency: Double {
        let index = Note.all.firstIndex(of: self)! - Note.all.firstIndex(of: Note(.a, .natural))!
        return 440.0 * pow(2.0, Double(index) / 12.0)
    }
}

class Pitch {
    let frequency: Double
    let note: Note
    let octave: Int

    private init(note: Note, octave: Int) {
        self.note = note
        self.octave = octave
        self.frequency = note.frequency * pow(2.0, Double(octave) - 4.0)
    }

    // All the notes from 0th octave to 8th octave.
    static let all = Array((0...8).map { octave -> [Pitch] in
        Note.all.map { note -> Pitch in
            Pitch(note: note, octave: octave)
        }
    }).joined()
    
    static func makePitchByFrequency(_ frequency: Double) -> Pitch {
        var results = all.map { pitch -> (pitch: Pitch, distance: Double) in
            (pitch: pitch, distance: abs(pitch.frequency - frequency))
        }

        results.sort { $0.distance < $1.distance }

        return results.first!.pitch
    }
}

// Pitcher from: https://medium.com/geekculture/simple-modular-classes-for-some-common-audiokit-v5-controls-fa5f264d376f
struct PitcherData {
    var pitch: Float = 0.0
    var amplitude: Float = 0.0
    var serial: Int = 0
    
}

protocol PitcherProtocol {
    var pitcherData: PitcherData { get }
    
}
class Pitcher: NSObject, ObservableObject {
    @Published var pitcherData: PitcherData = PitcherData() // initialize
    var engine = AudioEngine()
    var silence: Fader // see below
    var mic: AudioEngine.InputNode
    
    var engineRunning = false
    var trackerRunning = false
    
    var tracker: PitchTap!
    var serial = 0
    
    func update(_ pitch: AUValue, _ amp: AUValue) {
        serial += 1
        pitcherData = PitcherData(pitch: pitch, amplitude: amp, serial: serial)
        
    }
    
    override init(){
            guard let input = engine.input else {
                fatalError()
            }
            mic = input
            silence = Fader(mic, gain: 0)
            
            super.init()
            tracker = PitchTap(mic) { [weak self] pitch, amp in
                if let self = self{
                    if self.trackerRunning {
                        DispatchQueue.main.async {
                           self.update(pitch[0], amp[0])
                        }
                    }
                }
            }
        }
    
    func start(){
            do {
                if !engineRunning {
                    engine.output = silence
                    try engine.start()
                }
                engineRunning = true
                if !trackerRunning {
                    tracker.start()
                    trackerRunning = true
                }
            } catch let ex {
                print("#@83 \(Date().toDateAndTimeStringWithMilliSeconds()) ex: \(ex.localizedDescription)")
            }
        }
    
    func stop(){
        trackerRunning = false
    }
}
