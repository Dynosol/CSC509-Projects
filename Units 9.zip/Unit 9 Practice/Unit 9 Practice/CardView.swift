//
//  CardView.swift
//  Unit 9 Practice
//
//  Created by Sol Kim on 4/19/22.
//

import SwiftUI

struct CardView: View {
    @Binding var data: URLResult?
    
    @State var input: String = ""
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: sWidth/10)
                .foregroundColor(.white)
                .frame(width: sWidth*(0.8), height: sHeight*(0.3))
            
            RoundedRectangle(cornerRadius: sWidth/10)
                .foregroundColor(.tan)
                .frame(width: sWidth*(0.78), height: sHeight*(0.29))
            
            VStack {
                Text("Check email")
                    .font(.custom("", size: sHeight*(0.05)))
                
                TextField("Input", text: $input)
                    .frame(width: sWidth*(0.6))
                    .background(Color.lightGray)
                    .cornerRadius(sWidth/10)
                    .autocapitalization(.none)
                
                // https://stackoverflow.com/questions/60008549/is-it-possible-to-change-return-key-to-done-on-keyboard-with-swiftui
                ZStack {
                    RoundedRectangle(cornerRadius: sWidth/10)
                        .foregroundColor(.blue)
                    Text("Check Result")
                        .foregroundColor(.white)
                }
                .onTapGesture {
                    let urlString = "https://api.eva.pingutil.com/email?email=\(input)"
                    getData(from: urlString) { data in
                        self.data = data
                    }
                    
                    print("checked")
                }
                .frame(width: sWidth*(0.6), height: sHeight*(0.05))
                
                
                Text("Email deliverability: " + String(data?.data.deliverable ?? false))
                    .font(.custom("", size: sHeight*(0.02)))
            }
        }
    }
}
