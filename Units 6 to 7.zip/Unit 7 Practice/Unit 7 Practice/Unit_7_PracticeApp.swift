//
//  Unit_7_PracticeApp.swift
//  Unit 7 Practice
//
//  Created by Sol Kim on 2/7/22.
//

import SwiftUI

@main
struct Unit_7_PracticeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
