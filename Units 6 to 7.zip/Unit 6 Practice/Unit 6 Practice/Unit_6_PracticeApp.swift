//
//  Unit_6_PracticeApp.swift
//  Unit 6 Practice
//
//  Created by Sol Kim on 1/11/22.
//

import SwiftUI

@main
struct Unit_6_PracticeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
