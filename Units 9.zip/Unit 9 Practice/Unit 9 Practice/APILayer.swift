//
//  APILayer.swift
//  Unit 9 Practice
//
//  Created by Sol Kim on 4/19/22.
//

import Foundation

struct MyData: Codable {
    let email_address: String
    let domain: String
    let valid_syntax: Bool
    let disposable: Bool
    let webmail: Bool
    let deliverable: Bool
    let catch_all: Bool
    let gibberish: Bool
    let spam: Bool
}

struct URLResult: Codable {
    let status: String
    let data: MyData
}

func getData(from urlString: String, completion: @escaping (URLResult) -> Void) {
    guard let url = URL(string: urlString) else {
        // if here, url was bad
        return
    }

    URLSession.shared.dataTask(with: url) { data, response, error in
        if let data = data {
            // data non-optional, i.e. it actually exists
            let dataAsString = String(data: data, encoding: .utf8)
            if let dataAsString = dataAsString {
                print(dataAsString)
            }
            
            let decoder = JSONDecoder()
            
            if let verifiedData = try? decoder.decode(URLResult.self, from: data) {
                // successfully made the Swift objects
                completion(verifiedData)
            }
        }
    }.resume()
}


